import { useState } from "react";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { PetCard } from "../components/PetCard";
import { mockPets, cities, dogBreeds, catBreeds, type PetType, type ListingType, type Gender } from "../data/mockData";
import { SlidersHorizontal } from "lucide-react";

export function ExplorePets() {
  const [filters, setFilters] = useState({
    type: "" as PetType | "",
    breed: "",
    city: "",
    gender: "" as Gender | "",
    listingType: "" as ListingType | "",
    minAge: "",
    maxAge: "",
  });

  const [showFilters, setShowFilters] = useState(true);

  const filteredPets = mockPets.filter((pet) => {
    if (filters.type && pet.type !== filters.type) return false;
    if (filters.breed && pet.breed !== filters.breed) return false;
    if (filters.city && pet.city !== filters.city) return false;
    if (filters.gender && pet.gender !== filters.gender) return false;
    if (filters.listingType && pet.listingType !== filters.listingType) return false;
    if (filters.minAge && pet.age < parseInt(filters.minAge)) return false;
    if (filters.maxAge && pet.age > parseInt(filters.maxAge)) return false;
    return true;
  });

  const breeds = filters.type === "dog" ? dogBreeds : filters.type === "cat" ? catBreeds : [];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />

      <div className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Tüm İlanlar</h1>
          <p className="text-gray-600">
            {filteredPets.length} ilan bulundu
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <aside className={`lg:w-80 ${showFilters ? "block" : "hidden lg:block"}`}>
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-semibold text-lg flex items-center gap-2">
                  <SlidersHorizontal className="w-5 h-5" />
                  Filtreler
                </h2>
                <button
                  onClick={() => setFilters({
                    type: "",
                    breed: "",
                    city: "",
                    gender: "",
                    listingType: "",
                    minAge: "",
                    maxAge: "",
                  })}
                  className="text-sm text-orange-500 hover:text-orange-600"
                >
                  Temizle
                </button>
              </div>

              <div className="space-y-6">
                {/* Listing Type */}
                <div>
                  <label className="block text-sm font-medium mb-2">İlan Türü</label>
                  <select
                    value={filters.listingType}
                    onChange={(e) => setFilters({ ...filters, listingType: e.target.value as ListingType | "" })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  >
                    <option value="">Tümü</option>
                    <option value="adoption">Sahiplendirme</option>
                    <option value="mating">Çiftleştirme</option>
                  </select>
                </div>

                {/* Pet Type */}
                <div>
                  <label className="block text-sm font-medium mb-2">Hayvan Türü</label>
                  <select
                    value={filters.type}
                    onChange={(e) => setFilters({ ...filters, type: e.target.value as PetType | "", breed: "" })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  >
                    <option value="">Tümü</option>
                    <option value="dog">Köpek</option>
                    <option value="cat">Kedi</option>
                  </select>
                </div>

                {/* Breed */}
                {filters.type && (
                  <div>
                    <label className="block text-sm font-medium mb-2">Cins</label>
                    <select
                      value={filters.breed}
                      onChange={(e) => setFilters({ ...filters, breed: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    >
                      <option value="">Tümü</option>
                      {breeds.map((breed) => (
                        <option key={breed} value={breed}>{breed}</option>
                      ))}
                    </select>
                  </div>
                )}

                {/* City */}
                <div>
                  <label className="block text-sm font-medium mb-2">Şehir</label>
                  <select
                    value={filters.city}
                    onChange={(e) => setFilters({ ...filters, city: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  >
                    <option value="">Tümü</option>
                    {cities.map((city) => (
                      <option key={city} value={city}>{city}</option>
                    ))}
                  </select>
                </div>

                {/* Gender */}
                <div>
                  <label className="block text-sm font-medium mb-2">Cinsiyet</label>
                  <select
                    value={filters.gender}
                    onChange={(e) => setFilters({ ...filters, gender: e.target.value as Gender | "" })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  >
                    <option value="">Tümü</option>
                    <option value="male">Erkek</option>
                    <option value="female">Dişi</option>
                  </select>
                </div>

                {/* Age Range */}
                <div>
                  <label className="block text-sm font-medium mb-2">Yaş Aralığı</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      placeholder="Min"
                      value={filters.minAge}
                      onChange={(e) => setFilters({ ...filters, minAge: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      min="0"
                    />
                    <input
                      type="number"
                      placeholder="Max"
                      value={filters.maxAge}
                      onChange={(e) => setFilters({ ...filters, maxAge: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      min="0"
                    />
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* Pet Grid */}
          <main className="flex-1">
            {/* Mobile Filter Toggle */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="lg:hidden mb-4 w-full px-4 py-2 bg-white border border-gray-200 rounded-lg flex items-center justify-center gap-2"
            >
              <SlidersHorizontal className="w-5 h-5" />
              Filtreleri {showFilters ? "Gizle" : "Göster"}
            </button>

            {filteredPets.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredPets.map((pet) => (
                  <PetCard key={pet.id} pet={pet} />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-xl p-12 text-center">
                <p className="text-gray-500 mb-4">Filtrelere uygun ilan bulunamadı</p>
                <button
                  onClick={() => setFilters({
                    type: "",
                    breed: "",
                    city: "",
                    gender: "",
                    listingType: "",
                    minAge: "",
                    maxAge: "",
                  })}
                  className="text-orange-500 font-medium hover:text-orange-600"
                >
                  Filtreleri Temizle
                </button>
              </div>
            )}
          </main>
        </div>
      </div>

      <Footer />
    </div>
  );
}
