import { useState } from "react";
import { Link } from "react-router";
import { 
  Users, 
  Search,
  Filter,
  MoreVertical,
  Ban,
  CheckCircle,
  Eye,
  Trash2,
  Mail,
  TrendingUp
} from "lucide-react";

interface User {
  id: number;
  name: string;
  email: string;
  type: "user" | "shelter";
  status: "active" | "banned" | "pending";
  joinDate: string;
  listings: number;
  city: string;
}

export function AdminUsers() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<"all" | "user" | "shelter">("all");
  const [filterStatus, setFilterStatus] = useState<"all" | "active" | "banned" | "pending">("all");

  // Mock data
  const users: User[] = [
    {
      id: 1,
      name: "Ahmet Yılmaz",
      email: "ahmet@example.com",
      type: "user",
      status: "active",
      joinDate: "2026-01-15",
      listings: 3,
      city: "İstanbul"
    },
    {
      id: 2,
      name: "İstanbul Pati Barınağı",
      email: "info@istanbulpati.com",
      type: "shelter",
      status: "pending",
      joinDate: "2026-04-15",
      listings: 0,
      city: "İstanbul"
    },
    {
      id: 3,
      name: "Ayşe Kaya",
      email: "ayse@example.com",
      type: "user",
      status: "active",
      joinDate: "2026-02-20",
      listings: 5,
      city: "Ankara"
    },
    {
      id: 4,
      name: "Mehmet Demir",
      email: "mehmet@example.com",
      type: "user",
      status: "banned",
      joinDate: "2026-03-10",
      listings: 1,
      city: "İzmir"
    },
    {
      id: 5,
      name: "Ankara Hayvan Evi",
      email: "info@ankarahayvan.org",
      type: "shelter",
      status: "active",
      joinDate: "2025-12-01",
      listings: 23,
      city: "Ankara"
    },
  ];

  const filteredUsers = users.filter((user) => {
    const matchesSearch = user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === "all" || user.type === filterType;
    const matchesStatus = filterStatus === "all" || user.status === filterStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  const stats = {
    total: users.length,
    active: users.filter(u => u.status === "active").length,
    pending: users.filter(u => u.status === "pending").length,
    banned: users.filter(u => u.status === "banned").length,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Kullanıcı Yönetimi</h1>
              <p className="text-sm text-gray-500">Tüm kullanıcıları görüntüleyin ve yönetin</p>
            </div>
            <Link
              to="/admin"
              className="px-4 py-2 text-gray-600 hover:text-gray-900 text-sm font-medium"
            >
              ← Dashboard
            </Link>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-gray-200 min-h-screen sticky top-16">
          <nav className="p-4 space-y-2">
            <Link
              to="/admin"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium"
            >
              <TrendingUp className="w-5 h-5" />
              Dashboard
            </Link>
            <Link
              to="/admin/users"
              className="flex items-center gap-3 px-4 py-3 bg-orange-50 text-orange-600 rounded-lg font-medium"
            >
              <Users className="w-5 h-5" />
              Kullanıcılar
            </Link>
            <Link
              to="/admin/shelters"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium"
            >
              <Users className="w-5 h-5" />
              Barınaklar
            </Link>
            <Link
              to="/admin/listings"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium"
            >
              <Users className="w-5 h-5" />
              İlanlar
            </Link>
            
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="text-2xl font-bold mb-1">{stats.total}</div>
              <div className="text-sm text-gray-600">Toplam Kullanıcı</div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="text-2xl font-bold text-green-600 mb-1">{stats.active}</div>
              <div className="text-sm text-gray-600">Aktif</div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="text-2xl font-bold text-orange-600 mb-1">{stats.pending}</div>
              <div className="text-sm text-gray-600">Beklemede</div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="text-2xl font-bold text-red-600 mb-1">{stats.banned}</div>
              <div className="text-sm text-gray-600">Yasaklı</div>
            </div>
          </div>

          {/* Filters */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="İsim veya email ara..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>

              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value as any)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="all">Tüm Tipler</option>
                <option value="user">Bireysel Kullanıcı</option>
                <option value="shelter">Barınak</option>
              </select>

              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="all">Tüm Durumlar</option>
                <option value="active">Aktif</option>
                <option value="pending">Beklemede</option>
                <option value="banned">Yasaklı</option>
              </select>
            </div>
          </div>

          {/* Users Table */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                      Kullanıcı
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                      Tip
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                      Durum
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                      Kayıt Tarihi
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                      İlanlar
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                      İşlemler
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div>
                          <div className="font-medium text-gray-900">{user.name}</div>
                          <div className="text-sm text-gray-500">{user.email}</div>
                          <div className="text-xs text-gray-400">{user.city}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          user.type === "shelter"
                            ? "bg-purple-100 text-purple-800"
                            : "bg-blue-100 text-blue-800"
                        }`}>
                          {user.type === "shelter" ? "🏠 Barınak" : "👤 Bireysel"}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          user.status === "active"
                            ? "bg-green-100 text-green-800"
                            : user.status === "pending"
                            ? "bg-orange-100 text-orange-800"
                            : "bg-red-100 text-red-800"
                        }`}>
                          {user.status === "active" && <CheckCircle className="w-3 h-3 mr-1" />}
                          {user.status === "banned" && <Ban className="w-3 h-3 mr-1" />}
                          {user.status === "active" ? "Aktif" : user.status === "pending" ? "Beklemede" : "Yasaklı"}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {new Date(user.joinDate).toLocaleDateString('tr-TR')}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {user.listings} ilan
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="Görüntüle">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors" title="Mesaj Gönder">
                            <Mail className="w-4 h-4" />
                          </button>
                          {user.status !== "banned" ? (
                            <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Yasakla">
                              <Ban className="w-4 h-4" />
                            </button>
                          ) : (
                            <button className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors" title="Yasağı Kaldır">
                              <CheckCircle className="w-4 h-4" />
                            </button>
                          )}
                          <button className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors" title="Sil">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredUsers.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500">Kullanıcı bulunamadı</p>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}