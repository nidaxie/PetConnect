import { Link } from "react-router";
import { 
  Users, 
  Building2, 
  List, 
  TrendingUp, 
  Eye,
  CheckCircle,
  XCircle,
  Clock
} from "lucide-react";

export function AdminDashboard() {
  // Mock statistics
  const stats = {
    totalUsers: 1247,
    activeUsers: 892,
    totalShelters: 45,
    pendingShelters: 8,
    totalListings: 324,
    activeListings: 278
  };

  const recentActivities = [
    { id: 1, type: "user", action: "Yeni kullanıcı kaydı", name: "Ahmet Yılmaz", time: "5 dk önce" },
    { id: 2, type: "shelter", action: "Barınak onay bekliyor", name: "İstanbul Pati Barınağı", time: "15 dk önce" },
    { id: 3, type: "listing", action: "Yeni ilan eklendi", name: "Golden Retriever - Max", time: "1 saat önce" },
    { id: 4, type: "shelter", action: "Barınak onaylandı", name: "Ankara Hayvan Evi", time: "3 saat önce" },
    { id: 5, type: "user", action: "Yeni kullanıcı kaydı", name: "Zeynep Kaya", time: "4 saat önce" },
  ];

  const pendingShelterApprovals = [
    { 
      id: 1, 
      name: "İstanbul Pati Barınağı", 
      applicant: "Mehmet Demir",
      city: "İstanbul",
      date: "2026-04-15",
      documents: 3
    },
    { 
      id: 2, 
      name: "Ankara Dostları Barınağı", 
      applicant: "Ayşe Kaya",
      city: "Ankara",
      date: "2026-04-16",
      documents: 4
    },
    { 
      id: 3, 
      name: "İzmir Patiler Yuvası", 
      applicant: "Can Öztürk",
      city: "İzmir",
      date: "2026-04-17",
      documents: 2
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Admin Panel</h1>
              <p className="text-sm text-gray-500">PetConnect Yönetim Sistemi</p>
            </div>
            <div className="flex items-center gap-4">
              <Link
                to="/"
                className="px-4 py-2 text-gray-600 hover:text-gray-900 text-sm font-medium"
              >
                Siteye Dön
              </Link>
              <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-pink-500 rounded-full flex items-center justify-center text-white font-bold">
                A
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-gray-200 min-h-screen sticky top-16">
          <nav className="p-4 space-y-2">
            <Link
              to="/admin"
              className="flex items-center gap-3 px-4 py-3 bg-orange-50 text-orange-600 rounded-lg font-medium"
            >
              <TrendingUp className="w-5 h-5" />
              Dashboard
            </Link>
            <Link
              to="/admin/users"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium"
            >
              <Users className="w-5 h-5" />
              Kullanıcılar
            </Link>
            <Link
              to="/admin/shelters"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium relative"
            >
              <Building2 className="w-5 h-5" />
              Barınaklar
              {stats.pendingShelters > 0 && (
                null
              )}
            </Link>
            <Link
              to="/admin/listings"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium"
            >
              <List className="w-5 h-5" />
              İlanlar
            </Link>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <span className="text-xs text-green-600 font-medium">+12%</span>
              </div>
              <div className="text-2xl font-bold mb-1">{stats.totalUsers.toLocaleString()}</div>
              <div className="text-sm text-gray-600">Toplam Kullanıcı</div>
              <div className="text-xs text-gray-500 mt-2">{stats.activeUsers} aktif</div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-purple-600" />
                </div>
                <span className="text-xs text-orange-600 font-medium">{stats.pendingShelters} bekliyor</span>
              </div>
              <div className="text-2xl font-bold mb-1">{stats.totalShelters}</div>
              <div className="text-sm text-gray-600">Toplam Barınak</div>
              <div className="text-xs text-gray-500 mt-2">{stats.totalShelters - stats.pendingShelters} onaylı</div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                  <List className="w-6 h-6 text-orange-600" />
                </div>
                <span className="text-xs text-green-600 font-medium">+8%</span>
              </div>
              <div className="text-2xl font-bold mb-1">{stats.totalListings}</div>
              <div className="text-sm text-gray-600">Toplam İlan</div>
              <div className="text-xs text-gray-500 mt-2">{stats.activeListings} aktif</div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <span className="text-xs text-green-600 font-medium">Bu ay</span>
              </div>
              <div className="text-2xl font-bold mb-1">156</div>
              <div className="text-sm text-gray-600">Başarılı Sahiplendirme</div>
              <div className="text-xs text-gray-500 mt-2">+23% artış</div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Pending Shelter Approvals */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                  <h2 className="font-bold text-lg">Onay Bekleyen Barınaklar</h2>
                  <Link
                    to="/admin/shelters"
                    className="text-sm text-orange-500 font-medium hover:text-orange-600"
                  >
                    Tümünü Gör →
                  </Link>
                </div>
                <div className="divide-y divide-gray-100">
                  {pendingShelterApprovals.map((shelter) => (
                    <div key={shelter.id} className="p-6 hover:bg-gray-50">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-semibold text-gray-900 mb-1">{shelter.name}</h3>
                          <p className="text-sm text-gray-600">
                            Yetkili: {shelter.applicant} • {shelter.city}
                          </p>
                        </div>
                        <span className="px-3 py-1 bg-orange-100 text-orange-600 rounded-full text-xs font-medium">
                          Bekliyor
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {new Date(shelter.date).toLocaleDateString('tr-TR')}
                        </span>
                        <span>{shelter.documents} belge</span>
                      </div>
                      <div className="flex gap-2">
                        <Link
                          to={`/admin/shelters/${shelter.id}`}
                          className="flex-1 px-4 py-2 bg-blue-50 text-blue-600 rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors text-center"
                        >
                          İncele
                        </Link>
                        <button className="px-4 py-2 bg-green-50 text-green-600 rounded-lg text-sm font-medium hover:bg-green-100 transition-colors">
                          <CheckCircle className="w-4 h-4" />
                        </button>
                        <button className="px-4 py-2 bg-red-50 text-red-600 rounded-lg text-sm font-medium hover:bg-red-100 transition-colors">
                          <XCircle className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h2 className="font-bold text-lg">Son Aktiviteler</h2>
                </div>
                <div className="p-6 space-y-4">
                  {recentActivities.map((activity) => (
                    <div key={activity.id} className="flex items-start gap-3">
                      <div className={`w-2 h-2 rounded-full mt-2 ${
                        activity.type === 'user' ? 'bg-blue-500' :
                        activity.type === 'shelter' ? 'bg-purple-500' :
                        'bg-orange-500'
                      }`}></div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-gray-600">{activity.action}</p>
                        <p className="text-sm font-medium text-gray-900 truncate">{activity.name}</p>
                        <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Quick Stats Chart */}
          <div className="mt-6 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="font-bold text-lg mb-6">Bu Ay Özet</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">+124</div>
                <div className="text-sm text-gray-600">Yeni Kullanıcı</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">+8</div>
                <div className="text-sm text-gray-600">Yeni Barınak</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600 mb-2">+89</div>
                <div className="text-sm text-gray-600">Yeni İlan</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">156</div>
                <div className="text-sm text-gray-600">Tamamlanan Sahiplendirme</div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}