import { useState } from "react";
import { Link } from "react-router";
import { 
  Building2, 
  Search,
  CheckCircle,
  XCircle,
  Eye,
  Clock,
  FileText,
  MapPin,
  Phone,
  Mail,
  TrendingUp,
  Users,
  List,
  AlertTriangle
} from "lucide-react";

interface Shelter {
  id: number;
  name: string;
  applicant: string;
  email: string;
  phone: string;
  city: string;
  district: string;
  address: string;
  capacity: number;
  status: "pending" | "approved" | "rejected";
  documents: number;
  applicationDate: string;
  description: string;
  taxNumber?: string;
}

export function AdminShelters() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "pending" | "approved" | "rejected">("all");
  const [selectedShelter, setSelectedShelter] = useState<Shelter | null>(null);

  // Mock data
  const shelters: Shelter[] = [
    {
      id: 1,
      name: "İstanbul Pati Barınağı",
      applicant: "Mehmet Demir",
      email: "info@istanbulpati.com",
      phone: "+90 212 555 0001",
      city: "İstanbul",
      district: "Sarıyer",
      address: "Maslak Mahallesi, Pati Sokak No:15",
      capacity: 150,
      status: "pending",
      documents: 3,
      applicationDate: "2026-04-15",
      description: "2015 yılından beri hizmet veren, 150 hayvan kapasiteli barınak. Veteriner hizmetleri ve rehabilitasyon merkezi mevcut.",
      taxNumber: "1234567890"
    },
    {
      id: 2,
      name: "Ankara Hayvan Evi",
      applicant: "Ayşe Kaya",
      email: "info@ankarahayvan.org",
      phone: "+90 312 555 0002",
      city: "Ankara",
      district: "Çankaya",
      address: "Dikmen Mahallesi, Hayvan Caddesi No:42",
      capacity: 200,
      status: "approved",
      documents: 4,
      applicationDate: "2025-12-01",
      description: "Ankara'nın en büyük barınaklarından biri. 24 saat veteriner hizmeti sunulmaktadır.",
      taxNumber: "9876543210"
    },
    {
      id: 3,
      name: "İzmir Patiler Yuvası",
      applicant: "Can Öztürk",
      email: "info@izmirpatiler.com",
      phone: "+90 232 555 0003",
      city: "İzmir",
      district: "Karşıyaka",
      address: "Bostanlı Mahallesi, Sahil Yolu No:78",
      capacity: 80,
      status: "pending",
      documents: 2,
      applicationDate: "2026-04-17",
      description: "Küçük ama özenle bakılan barınak. Özellikle kedi bakımında uzmanlaşmış."
    },
    {
      id: 4,
      name: "Antalya Can Dostları",
      applicant: "Zeynep Yıldız",
      email: "info@antalyacandostlari.org",
      phone: "+90 242 555 0004",
      city: "Antalya",
      district: "Muratpaşa",
      address: "Lara Mahallesi, Deniz Sokak No:23",
      capacity: 120,
      status: "rejected",
      documents: 1,
      applicationDate: "2026-04-10",
      description: "Belgeler eksik olduğu için reddedildi."
    },
  ];

  const filteredShelters = shelters.filter((shelter) => {
    const matchesSearch = shelter.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         shelter.applicant.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         shelter.city.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === "all" || shelter.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: shelters.length,
    pending: shelters.filter(s => s.status === "pending").length,
    approved: shelters.filter(s => s.status === "approved").length,
    rejected: shelters.filter(s => s.status === "rejected").length,
  };

  const approveShelter = (id: number) => {
    alert(`Barınak #${id} onaylandı!`);
  };

  const rejectShelter = (id: number) => {
    const reason = prompt("Ret nedeni:");
    if (reason) {
      alert(`Barınak #${id} reddedildi. Neden: ${reason}`);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Barınak Yönetimi</h1>
              <p className="text-sm text-gray-500">Barınak başvurularını onaylayın veya reddedin</p>
            </div>
            <Link
              to="/admin"
              className="px-4 py-2 text-gray-600 hover:text-gray-900 text-sm font-medium"
            >
              ← Dashboard
            </Link>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-gray-200 min-h-screen sticky top-16">
          <nav className="p-4 space-y-2">
            <Link
              to="/admin"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium"
            >
              <TrendingUp className="w-5 h-5" />
              Dashboard
            </Link>
            <Link
              to="/admin/users"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium"
            >
              <Users className="w-5 h-5" />
              Kullanıcılar
            </Link>
            <Link
              to="/admin/shelters"
              className="flex items-center gap-3 px-4 py-3 bg-orange-50 text-orange-600 rounded-lg font-medium"
            >
              <Building2 className="w-5 h-5" />
              Barınaklar
            </Link>
            <Link
              to="/admin/listings"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium"
            >
              <List className="w-5 h-5" />
              İlanlar
            </Link>
            <Link
              to="/admin/reports"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium"
            >
              <AlertTriangle className="w-5 h-5" />
              Şikayetler
            </Link>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="text-2xl font-bold mb-1">{stats.total}</div>
              <div className="text-sm text-gray-600">Toplam Barınak</div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="text-2xl font-bold text-orange-600 mb-1">{stats.pending}</div>
              <div className="text-sm text-gray-600">Onay Bekliyor</div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="text-2xl font-bold text-green-600 mb-1">{stats.approved}</div>
              <div className="text-sm text-gray-600">Onaylı</div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="text-2xl font-bold text-red-600 mb-1">{stats.rejected}</div>
              <div className="text-sm text-gray-600">Reddedildi</div>
            </div>
          </div>

          {/* Filters */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Barınak adı, yetkili veya şehir ara..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>

              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="all">Tüm Durumlar</option>
                <option value="pending">Onay Bekliyor</option>
                <option value="approved">Onaylı</option>
                <option value="rejected">Reddedildi</option>
              </select>
            </div>
          </div>

          {/* Shelters Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredShelters.map((shelter) => (
              <div key={shelter.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-gray-900 mb-1">{shelter.name}</h3>
                      <p className="text-sm text-gray-600">Yetkili: {shelter.applicant}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      shelter.status === "pending" ? "bg-orange-100 text-orange-600" :
                      shelter.status === "approved" ? "bg-green-100 text-green-600" :
                      "bg-red-100 text-red-600"
                    }`}>
                      {shelter.status === "pending" ? "Bekliyor" :
                       shelter.status === "approved" ? "Onaylı" : "Reddedildi"}
                    </span>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="w-4 h-4" />
                      <span>{shelter.city}, {shelter.district}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mail className="w-4 h-4" />
                      <span>{shelter.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Phone className="w-4 h-4" />
                      <span>{shelter.phone}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Building2 className="w-4 h-4" />
                      <span>Kapasite: {shelter.capacity} hayvan</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <FileText className="w-4 h-4" />
                      <span>{shelter.documents} belge yüklendi</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4" />
                      <span>Başvuru: {new Date(shelter.applicationDate).toLocaleDateString('tr-TR')}</span>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-3 mb-4">
                    <p className="text-sm text-gray-700 line-clamp-2">{shelter.description}</p>
                  </div>

                  <button
                    onClick={() => setSelectedShelter(shelter)}
                    className="w-full px-4 py-2 bg-blue-50 text-blue-600 rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors mb-3"
                  >
                    <Eye className="w-4 h-4 inline mr-2" />
                    Detaylı İncele
                  </button>

                  {shelter.status === "pending" && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => approveShelter(shelter.id)}
                        className="flex-1 px-4 py-2 bg-green-50 text-green-600 rounded-lg text-sm font-medium hover:bg-green-100 transition-colors flex items-center justify-center gap-2"
                      >
                        <CheckCircle className="w-4 h-4" />
                        Onayla
                      </button>
                      <button
                        onClick={() => rejectShelter(shelter.id)}
                        className="flex-1 px-4 py-2 bg-red-50 text-red-600 rounded-lg text-sm font-medium hover:bg-red-100 transition-colors flex items-center justify-center gap-2"
                      >
                        <XCircle className="w-4 h-4" />
                        Reddet
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {filteredShelters.length === 0 && (
            <div className="text-center py-12 bg-white rounded-xl">
              <Building2 className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">Barınak bulunamadı</p>
            </div>
          )}
        </main>
      </div>

      {/* Detail Modal */}
      {selectedShelter && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center">
              <h2 className="text-xl font-bold">{selectedShelter.name}</h2>
              <button
                onClick={() => setSelectedShelter(null)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div>
                <h3 className="font-semibold mb-3">Barınak Bilgileri</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-gray-600">Barınak Adı</label>
                    <p className="font-medium">{selectedShelter.name}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-600">Yetkili Kişi</label>
                    <p className="font-medium">{selectedShelter.applicant}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-600">E-posta</label>
                    <p className="font-medium">{selectedShelter.email}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-600">Telefon</label>
                    <p className="font-medium">{selectedShelter.phone}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-600">Kapasite</label>
                    <p className="font-medium">{selectedShelter.capacity} hayvan</p>
                  </div>
                  {selectedShelter.taxNumber && (
                    <div>
                      <label className="text-sm text-gray-600">Vergi No</label>
                      <p className="font-medium">{selectedShelter.taxNumber}</p>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-3">Adres Bilgileri</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-gray-600">Şehir</label>
                    <p className="font-medium">{selectedShelter.city}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-600">İlçe</label>
                    <p className="font-medium">{selectedShelter.district}</p>
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-sm text-gray-600">Tam Adres</label>
                    <p className="font-medium">{selectedShelter.address}</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-3">Açıklama</h3>
                <p className="text-gray-700">{selectedShelter.description}</p>
              </div>

              <div>
                <h3 className="font-semibold mb-3">Yüklenen Belgeler ({selectedShelter.documents})</h3>
                <div className="space-y-2">
                  {Array.from({ length: selectedShelter.documents }).map((_, i) => (
                    <div key={i} className="flex items-center justify-between bg-gray-50 px-4 py-3 rounded-lg">
                      <div className="flex items-center gap-3">
                        <FileText className="w-5 h-5 text-gray-400" />
                        <span className="text-sm font-medium">Belge_{i + 1}.pdf</span>
                      </div>
                      <button className="px-3 py-1 bg-blue-50 text-blue-600 rounded text-sm font-medium hover:bg-blue-100">
                        İndir
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {selectedShelter.status === "pending" && (
                <div className="flex gap-3 pt-4 border-t border-gray-200">
                  <button
                    onClick={() => {
                      approveShelter(selectedShelter.id);
                      setSelectedShelter(null);
                    }}
                    className="flex-1 px-6 py-3 bg-green-500 text-white rounded-xl font-medium hover:bg-green-600 transition-colors flex items-center justify-center gap-2"
                  >
                    <CheckCircle className="w-5 h-5" />
                    Barınağı Onayla
                  </button>
                  <button
                    onClick={() => {
                      rejectShelter(selectedShelter.id);
                      setSelectedShelter(null);
                    }}
                    className="flex-1 px-6 py-3 bg-red-500 text-white rounded-xl font-medium hover:bg-red-600 transition-colors flex items-center justify-center gap-2"
                  >
                    <XCircle className="w-5 h-5" />
                    Reddet
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}