import { useState } from "react";
import { Link } from "react-router";
import { 
  List, 
  Search,
  Eye,
  Edit,
  Trash2,
  TrendingUp,
  Users,
  Building2,
  Filter,
  CheckCircle,
  XCircle
} from "lucide-react";
import { mockPets } from "../../data/mockData";

export function AdminListings() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<"all" | "adoption" | "mating">("all");
  const [filterSpecies, setFilterSpecies] = useState<"all" | "dog" | "cat" | "bird" | "other">("all");
  const [filterStatus, setFilterStatus] = useState<"all" | "active" | "inactive">("all");

  // Using mock data
  const listings = mockPets.map((pet, index) => ({
    ...pet,
    status: index % 5 === 0 ? "inactive" : "active",
    views: Math.floor(Math.random() * 200) + 20
  }));

  const filteredListings = listings.filter((listing) => {
    const matchesSearch = listing.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         listing.breed.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         listing.city.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === "all" || listing.type === filterType;
    const matchesSpecies = filterSpecies === "all" || listing.species === filterSpecies;
    const matchesStatus = filterStatus === "all" || listing.status === filterStatus;
    return matchesSearch && matchesType && matchesSpecies && matchesStatus;
  });

  const stats = {
    total: listings.length,
    active: listings.filter(l => l.status === "active").length,
    inactive: listings.filter(l => l.status === "inactive").length,
    reported: listings.filter(l => l.reports > 0).length,
  };

  const deleteListing = (id: number) => {
    if (confirm("Bu ilanı silmek istediğinizden emin misiniz?")) {
      alert(`İlan #${id} silindi!`);
    }
  };

  const toggleStatus = (id: number, currentStatus: string) => {
    const newStatus = currentStatus === "active" ? "inactive" : "active";
    alert(`İlan #${id} durumu "${newStatus}" olarak güncellendi!`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">İlan Yönetimi</h1>
              <p className="text-sm text-gray-500">Tüm ilanları görüntüleyin ve yönetin</p>
            </div>
            <Link
              to="/admin"
              className="px-4 py-2 text-gray-600 hover:text-gray-900 text-sm font-medium"
            >
              ← Dashboard
            </Link>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-gray-200 min-h-screen sticky top-16">
          <nav className="p-4 space-y-2">
            <Link
              to="/admin"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium"
            >
              <TrendingUp className="w-5 h-5" />
              Dashboard
            </Link>
            <Link
              to="/admin/users"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium"
            >
              <Users className="w-5 h-5" />
              Kullanıcılar
            </Link>
            <Link
              to="/admin/shelters"
              className="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-gray-50 rounded-lg font-medium"
            >
              <Building2 className="w-5 h-5" />
              Barınaklar
            </Link>
            <Link
              to="/admin/listings"
              className="flex items-center gap-3 px-4 py-3 bg-orange-50 text-orange-600 rounded-lg font-medium"
            >
              <List className="w-5 h-5" />
              İlanlar
            </Link>
            
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="text-2xl font-bold mb-1">{stats.total}</div>
              <div className="text-sm text-gray-600">Toplam İlan</div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="text-2xl font-bold text-green-600 mb-1">{stats.active}</div>
              <div className="text-sm text-gray-600">Aktif İlan</div>
            </div>
            <div className="bg-white p-6 shadow-sm border border-gray-200 rounded-[14px]">
              <div className="text-2xl font-bold text-gray-600 mb-1">{stats.inactive}</div>
              <div className="text-sm text-gray-600">Pasif İlan</div>
            </div>
            
          </div>

          {/* Filters */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="İlan ara..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>

              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value as any)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="all">Tüm Tipler</option>
                <option value="adoption">Sahiplendirme</option>
                <option value="mating">Çiftleştirme</option>
              </select>

              <select
                value={filterSpecies}
                onChange={(e) => setFilterSpecies(e.target.value as any)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="all">Tüm Türler</option>
                <option value="dog">Köpek</option>
                <option value="cat">Kedi</option>
                <option value="bird">Kuş</option>
                <option value="other">Diğer</option>
              </select>

              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="all">Tüm Durumlar</option>
                <option value="active">Aktif</option>
                <option value="inactive">Pasif</option>
              </select>
            </div>
          </div>

          {/* Listings Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredListings.map((listing) => (
              <div key={listing.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden group">
                <div className="relative">
                  <img
                    src={listing.images[0]}
                    alt={listing.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-2 right-2 flex gap-2">
                    <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                      listing.status === "active"
                        ? "bg-green-500 text-white"
                        : "bg-gray-500 text-white"
                    }`}>
                      {listing.status === "active" ? "Aktif" : "Pasif"}
                    </span>
                  </div>
                </div>

                <div className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-bold text-gray-900">{listing.name}</h3>
                      <p className="text-sm text-gray-600">{listing.breed}</p>
                    </div>
                    <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                      listing.type === "adoption"
                        ? "bg-blue-100 text-blue-600"
                        : "bg-purple-100 text-purple-600"
                    }`}>
                      {listing.type === "adoption" ? "Sahiplendirme" : "Çiftleştirme"}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                    <span>{listing.city}</span>
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {listing.views}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-gray-500 mb-4">
                    <span className={`px-2 py-1 rounded ${
                      listing.ownerType === "shelter"
                        ? "bg-purple-50 text-purple-600"
                        : "bg-blue-50 text-blue-600"
                    }`}>
                      {listing.ownerType === "shelter" ? "🏠 Barınak" : "👤 Bireysel"}
                    </span>
                    <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded">
                      {listing.age} • {listing.gender === "male" ? "Erkek" : "Dişi"}
                    </span>
                  </div>

                  <div className="flex gap-2">
                    <Link
                      to={`/pets/${listing.id}`}
                      className="flex-1 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors text-center"
                    >
                      <Eye className="w-4 h-4 inline mr-1" />
                      Görüntüle
                    </Link>
                    <button
                      onClick={() => toggleStatus(listing.id, listing.status)}
                      className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                        listing.status === "active"
                          ? "bg-gray-50 text-gray-600 hover:bg-gray-100"
                          : "bg-green-50 text-green-600 hover:bg-green-100"
                      }`}
                      title={listing.status === "active" ? "Pasif Yap" : "Aktif Yap"}
                    >
                      {listing.status === "active" ? <XCircle className="w-4 h-4" /> : <CheckCircle className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={() => deleteListing(listing.id)}
                      className="px-3 py-2 bg-red-50 text-red-600 rounded-lg text-sm font-medium hover:bg-red-100 transition-colors"
                      title="Sil"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredListings.length === 0 && (
            <div className="text-center py-12 bg-white rounded-xl">
              <List className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">İlan bulunamadı</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}