import { useState } from "react";
import { Link } from "react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { mockPets } from "../data/mockData";
import { PlusCircle, Edit, Trash2, Eye, MessageSquare, CheckCircle, XCircle } from "lucide-react";

export function MyListings() {
  const [activeTab, setActiveTab] = useState<"all" | "adoption" | "mating">("all");
  
  // Mock user listings
  const myListings = mockPets.filter((pet) => pet.ownerType === "user");
  
  const filteredListings = activeTab === "all" 
    ? myListings 
    : myListings.filter((pet) => pet.listingType === activeTab);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />

      <div className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">İlanlarım</h1>
            <p className="text-gray-600">{filteredListings.length} ilan bulundu</p>
          </div>
          <Link
            to="/dashboard/create"
            className="px-6 py-3 bg-gradient-to-r from-orange-500 to-pink-500 text-white rounded-xl font-medium hover:shadow-lg transition-shadow flex items-center gap-2"
          >
            <PlusCircle className="w-5 h-5" />
            Yeni İlan
          </Link>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-xl p-1 shadow-sm border border-gray-200 mb-6 inline-flex">
          <button
            onClick={() => setActiveTab("all")}
            className={`px-6 py-2 rounded-lg font-medium transition-colors ${
              activeTab === "all"
                ? "bg-orange-500 text-white"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            Tümü
          </button>
          <button
            onClick={() => setActiveTab("adoption")}
            className={`px-6 py-2 rounded-lg font-medium transition-colors ${
              activeTab === "adoption"
                ? "bg-orange-500 text-white"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            Sahiplendirme
          </button>
          <button
            onClick={() => setActiveTab("mating")}
            className={`px-6 py-2 rounded-lg font-medium transition-colors ${
              activeTab === "mating"
                ? "bg-orange-500 text-white"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            Çiftleştirme
          </button>
        </div>

        {/* Listings */}
        {filteredListings.length > 0 ? (
          <div className="space-y-4">
            {filteredListings.map((pet) => (
              <div
                key={pet.id}
                className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
              >
                <div className="flex flex-col md:flex-row gap-6">
                  {/* Image */}
                  <Link to={`/pets/${pet.id}`} className="flex-shrink-0">
                    <img
                      src={pet.images[0]}
                      alt={pet.name}
                      className="w-full md:w-48 h-48 rounded-xl object-cover hover:opacity-90 transition-opacity"
                    />
                  </Link>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <Link
                          to={`/pets/${pet.id}`}
                          className="text-xl font-bold mb-2 hover:text-orange-500 transition-colors inline-block"
                        >
                          {pet.name}
                        </Link>
                        <p className="text-gray-600">
                          {pet.breed} • {pet.age} yaşında • {pet.gender === "male" ? "Erkek" : "Dişi"}
                        </p>
                        <p className="text-sm text-gray-500 mt-1">{pet.city}</p>
                      </div>
                      
                      <div className="inline-flex items-center gap-1 px-3 py-1 bg-green-50 text-green-600 rounded-lg text-sm font-medium">
                        <CheckCircle className="w-4 h-4" />
                        Aktif
                      </div>
                    </div>

                    <p className="text-gray-700 mb-4 line-clamp-2">{pet.description}</p>

                    {/* Stats */}
                    <div className="flex flex-wrap gap-4 mb-4">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Eye className="w-4 h-4" />
                        <span>45 görüntülenme</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <MessageSquare className="w-4 h-4" />
                        <span>3 mesaj</span>
                      </div>
                      <div className="text-sm text-gray-500">
                        {new Date(pet.createdAt).toLocaleDateString("tr-TR")}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-wrap gap-3">
                      <Link
                        to={`/pets/${pet.id}`}
                        className="px-4 py-2 bg-orange-50 text-orange-600 rounded-lg text-sm font-medium hover:bg-orange-100 transition-colors flex items-center gap-2"
                      >
                        <Eye className="w-4 h-4" />
                        Görüntüle
                      </Link>
                      <button className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors flex items-center gap-2">
                        <Edit className="w-4 h-4" />
                        Düzenle
                      </button>
                      <button className="px-4 py-2 bg-gray-50 text-gray-600 rounded-lg text-sm font-medium hover:bg-gray-100 transition-colors flex items-center gap-2">
                        <XCircle className="w-4 h-4" />
                        Pasif Yap
                      </button>
                      <button className="px-4 py-2 bg-red-50 text-red-600 rounded-lg text-sm font-medium hover:bg-red-100 transition-colors flex items-center gap-2">
                        <Trash2 className="w-4 h-4" />
                        Sil
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-xl p-12 text-center">
            <PlusCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Henüz ilan yok</h3>
            <p className="text-gray-600 mb-6">İlk ilanınızı oluşturarak başlayın</p>
            <Link
              to="/dashboard/create"
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-pink-500 text-white rounded-xl font-medium hover:shadow-lg transition-shadow"
            >
              <PlusCircle className="w-5 h-5" />
              Yeni İlan Oluştur
            </Link>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
