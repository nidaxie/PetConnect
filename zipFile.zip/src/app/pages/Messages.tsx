import { useState } from "react";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { Search, Send, MoreVertical, Phone, Video } from "lucide-react";

interface Message {
  id: string;
  text: string;
  sender: "me" | "other";
  timestamp: string;
}

interface Conversation {
  id: string;
  userName: string;
  userAvatar: string;
  petName: string;
  lastMessage: string;
  timestamp: string;
  unread: number;
}

const mockConversations: Conversation[] = [
  {
    id: "1",
    userName: "Ayşe Yılmaz",
    userAvatar: "AY",
    petName: "Pamuk",
    lastMessage: "Hayvanı bu hafta ziyaret edebilir miyim?",
    timestamp: "10:30",
    unread: 2,
  },
  {
    id: "2",
    userName: "Mehmet Demir",
    userAvatar: "MD",
    petName: "Luna",
    lastMessage: "Teşekkürler, bilgi için",
    timestamp: "Dün",
    unread: 0,
  },
  {
    id: "3",
    userName: "Zeynep Kaya",
    userAvatar: "ZK",
    petName: "Max",
    lastMessage: "Aşı kartını görebilir miyim?",
    timestamp: "2 gün önce",
    unread: 0,
  },
];

const mockMessages: Message[] = [
  {
    id: "1",
    text: "Merhaba, Pamuk hakkında bilgi almak istiyorum",
    sender: "other",
    timestamp: "10:15",
  },
  {
    id: "2",
    text: "Merhaba! Tabii, ne öğrenmek istersiniz?",
    sender: "me",
    timestamp: "10:18",
  },
  {
    id: "3",
    text: "Çocuklarla arası nasıl? Ve eğitim almış mı?",
    sender: "other",
    timestamp: "10:20",
  },
  {
    id: "4",
    text: "Çok sevecen bir köpek, çocuklarla harika geçiniyor. Temel itaat eğitimi almış durumda.",
    sender: "me",
    timestamp: "10:22",
  },
  {
    id: "5",
    text: "Harika! Hayvanı bu hafta ziyaret edebilir miyim?",
    sender: "other",
    timestamp: "10:30",
  },
];

export function Messages() {
  const [selectedConversation, setSelectedConversation] = useState<string>(mockConversations[0].id);
  const [messageText, setMessageText] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const activeConversation = mockConversations.find((c) => c.id === selectedConversation);
  const filteredConversations = mockConversations.filter((conv) =>
    conv.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    conv.petName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageText.trim()) {
      // Handle send message
      setMessageText("");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />

      <div className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden h-[calc(100vh-12rem)]">
          <div className="flex h-full">
            {/* Conversations List */}
            <div className="w-full md:w-96 border-r border-gray-200 flex flex-col">
              {/* Search */}
              <div className="p-4 border-b border-gray-200">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Ara..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                  />
                </div>
              </div>

              {/* Conversations */}
              <div className="flex-1 overflow-y-auto">
                {filteredConversations.map((conv) => (
                  <button
                    key={conv.id}
                    onClick={() => setSelectedConversation(conv.id)}
                    className={`w-full p-4 flex items-start gap-3 hover:bg-gray-50 transition-colors border-b border-gray-100 ${
                      selectedConversation === conv.id ? "bg-orange-50" : ""
                    }`}
                  >
                    {/* Avatar */}
                    <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-pink-500 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">
                      {conv.userAvatar}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0 text-left">
                      <div className="flex justify-between items-baseline mb-1">
                        <h3 className="font-semibold truncate">{conv.userName}</h3>
                        <span className="text-xs text-gray-500 flex-shrink-0 ml-2">
                          {conv.timestamp}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500 mb-1">İlan: {conv.petName}</p>
                      <p className="text-sm text-gray-600 truncate">{conv.lastMessage}</p>
                    </div>

                    {/* Unread Badge */}
                    {conv.unread > 0 && (
                      <div className="w-6 h-6 bg-orange-500 text-white rounded-full flex items-center justify-center text-xs font-medium flex-shrink-0">
                        {conv.unread}
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Messages */}
            <div className="hidden md:flex flex-1 flex-col">
              {activeConversation ? (
                <>
                  {/* Header */}
                  <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-pink-500 rounded-full flex items-center justify-center text-white font-semibold">
                        {activeConversation.userAvatar}
                      </div>
                      <div>
                        <h3 className="font-semibold">{activeConversation.userName}</h3>
                        <p className="text-sm text-gray-500">İlan: {activeConversation.petName}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <Phone className="w-5 h-5 text-gray-600" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <Video className="w-5 h-5 text-gray-600" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                        <MoreVertical className="w-5 h-5 text-gray-600" />
                      </button>
                    </div>
                  </div>

                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {mockMessages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.sender === "me" ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-md px-4 py-2 rounded-2xl ${
                            message.sender === "me"
                              ? "bg-gradient-to-r from-orange-500 to-pink-500 text-white"
                              : "bg-gray-100 text-gray-900"
                          }`}
                        >
                          <p className="text-sm">{message.text}</p>
                          <p
                            className={`text-xs mt-1 ${
                              message.sender === "me" ? "text-orange-100" : "text-gray-500"
                            }`}
                          >
                            {message.timestamp}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Input */}
                  <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-200">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={messageText}
                        onChange={(e) => setMessageText(e.target.value)}
                        placeholder="Mesajınızı yazın..."
                        className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      />
                      <button
                        type="submit"
                        disabled={!messageText.trim()}
                        className="px-6 py-3 bg-gradient-to-r from-orange-500 to-pink-500 text-white rounded-xl font-medium hover:shadow-lg transition-shadow disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                      >
                        <Send className="w-5 h-5" />
                        Gönder
                      </button>
                    </div>
                  </form>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center text-gray-500">
                  Bir konuşma seçin
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
