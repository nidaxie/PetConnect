import { Link, useLocation } from "react-router";
import { Heart, User, PawPrint, Home } from "lucide-react";

export function Header() {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-pink-500 rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform">
              <PawPrint className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
              PetConnect
            </span>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link
              to="/"
              className={`text-sm font-medium transition-colors flex items-center gap-1 ${
                isActive("/")
                  ? "text-orange-500"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              <Home className="w-4 h-4" />
              Ana Sayfa
            </Link>
            <Link
              to="/explore"
              className={`text-sm font-medium transition-colors ${
                isActive("/explore")
                  ? "text-orange-500"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              İlanlar
            </Link>
            <Link
              to="/shelters"
              className={`text-sm font-medium transition-colors ${
                isActive("/shelters")
                  ? "text-orange-500"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Barınaklar
            </Link>
            <Link
              to="/how-it-works"
              className={`text-sm font-medium transition-colors ${
                isActive("/how-it-works")
                  ? "text-orange-500"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Nasıl Çalışır?
            </Link>
            <Link
              to="/dashboard"
              className={`text-sm font-medium transition-colors ${
                isActive("/dashboard")
                  ? "text-orange-500"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Panelim
            </Link>
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <Link
              to="/dashboard/favorites"
              className="p-2 text-gray-600 hover:text-orange-500 hover:bg-orange-50 rounded-lg transition-colors"
              title="Favoriler"
            >
              <Heart className="w-5 h-5" />
            </Link>
            <Link
              to="/login"
              className="p-2 text-gray-600 hover:text-orange-500 hover:bg-orange-50 rounded-lg transition-colors"
              title="Profil"
            >
              <User className="w-5 h-5" />
            </Link>
            <Link
              to="/dashboard/create"
              className="px-4 py-2 bg-gradient-to-r from-orange-500 to-pink-500 text-white rounded-lg text-sm font-medium hover:shadow-lg transition-shadow"
            >
              İlan Ver
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}